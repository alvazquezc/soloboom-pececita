# soloboom-pececita

Proxy API para obtener la información de Pececita_1k desde SoloBoom.

### Cómo usarlo

1. Sube este repositorio a GitHub.
2. En Railway: New Project → Deploy from GitHub Repo.
3. Railway instalará node automáticamente.
4. Obtén tu dominio en Settings → Domains.
5. Endpoint final:
   https://<tu-dominio>.up.railway.app/api/pececita
